function kkk = add(ConvNet)
kkk=ConvNet.F1 + 100;